import sys
import xbmcplugin
import xbmcgui
import xbmc
import urllib
import json

# Set up the plugin parameters
plugin_handle = int(sys.argv[1])

def list_categories():
    # Create some categories for Movies and TV Shows
    categories = [
        {'name': 'Movies', 'url': 'http://example.com/movies'},
        {'name': 'TV Shows', 'url': 'http://example.com/tvshows'}
    ]
    
    for category in categories:
        li = xbmcgui.ListItem(label=category['name'])
        url = category['url']
        xbmcplugin.addDirectoryItem(plugin_handle, url, li, True)
    
    xbmcplugin.endOfDirectory(plugin_handle)

def list_movies(url):
    # Fetch and display movies (this is just a static example; you would integrate an API)
    movies = [
        {'title': 'Movie 1', 'url': 'http://example.com/movie1.mp4'},
        {'title': 'Movie 2', 'url': 'http://example.com/movie2.mp4'}
    ]
    
    for movie in movies:
        li = xbmcgui.ListItem(label=movie['title'])
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(plugin_handle, movie['url'], li)
    
    xbmcplugin.endOfDirectory(plugin_handle)

def play_video(url):
    # This function plays the video URL
    li = xbmcgui.ListItem(path=url)
    xbmc.Player().play(url, li)

# Main logic based on parameters
params = urllib.parse.parse_qs(sys.argv[2][1:])
url = params.get('url', None)

if url:
    # If there's a URL parameter, show movies/TV shows from that category or play a video
    if 'movies' in url[0]:
        list_movies(url[0])
    else:
        play_video(url[0])
else:
    # If no URL, show categories (Movies, TV Shows)
    list_categories()
